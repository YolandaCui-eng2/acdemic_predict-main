# acdemic_predict
predict academic crisis by using data about academic procrastination behavior.
